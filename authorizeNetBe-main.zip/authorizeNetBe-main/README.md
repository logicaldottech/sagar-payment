// dev env variables

apiLoginKey
transactionKey
paymentDataValue